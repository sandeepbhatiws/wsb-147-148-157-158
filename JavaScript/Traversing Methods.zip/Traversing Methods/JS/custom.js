

// // var data = document.getElementById('row2').parentNode.innerHTML

// // var data = document.getElementById('row2').parentElement.innerHTML


// // var data = document.getElementById('row2').parentNode
// // console.log(data);

// var dataa = document.getElementById('row2').parentElement
// console.log(dataa);
// // console.log(data);


// var data = document.getElementById('outer').childNodes;

// console.log(data);


// var data = document.getElementById('outer').children;

// console.log(data);

// var data = document.getElementById('outer').firstElementChild;

// console.log(data);

// var data = document.getElementById('outer').lastElementChild;

// console.log(data);

// var data = document.getElementById('content').hasChildNodes();

// console.log(data);

// var data = document.getElementById('row3').nextElementSibling;
// console.log(data);

var data = document.getElementById('row1').previousElementSibling;
console.log(data);