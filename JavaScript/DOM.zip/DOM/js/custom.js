

// var output = document.getElementById('row').innerText;

// document.getElementById('output').innerText = output;
// // console.log(output.innerText);


// var output = document.getElementById('row').innerHTML;

// document.getElementById("output").innerHTML = output;
// // console.log(output);


// var newdata = document.getElementById('row1').innerText;
// console.log(newdata);



var allData = document.querySelectorAll('div');

console.log(allData);